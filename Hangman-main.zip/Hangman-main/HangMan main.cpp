/*
prepared by 
Essam abosalem  
Asser mazin 
sama 
youmna magdi 
ziad ahmed
*/


#include <iostream>
using namespace std;
#include "HangMan.h"

int main()
{
	HangMan h;
	h.Menu();
	return 0;
}